makeMyRectangleOverlay <-
function (start, end, region = NULL, coords = c("genomic", "absolute"), 
    dp = NULL,heights) 
{
    coords <- match.arg(coords)
    if (is.null(dp)) 
        dp <- getClass("RectangleOverlay")@prototype@dp
    new("myRectangleOverlay", start = start, end = end, region = region, 
        coords = coords, dp = dp,heights=heights)
}
