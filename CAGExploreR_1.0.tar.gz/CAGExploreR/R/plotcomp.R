plotcomp <-
function(x,gene)
{
	gene = gene[1]
	if(is.na(match(gene,names(x$data))[1])) {cat(paste0("Sorry there's no gene ",gene,"\n","Did you mean: ",paste(grep(gene,names(x$data),value=T,ignore.case=T),collapse=","),"?"));return(1)}
	PROMS = plot.switch(x$data[match(gene,names(x$data))[1]],lib.counts=x$depth,coverage=x$coverage)
	return(PROMS)
}
