plot.switch <-
function(x,lib.counts,coverage,GENE)
{
mart=new("Mart")
x = x[order(-rowSums(x)),]
mydata = t(t(as.matrix(x))/colSums(as.matrix(x))) #percentages
mydata[is.na(mydata)] = 0
mydata.raw = as.matrix(x)
dendro = as.dendrogram(hclust(dist(t(mydata))))
#mydata.raw = mydata.raw[,order(mydata[1,])]
#my.lib.counts = lib.counts[order(mydata[1,])]
#mydata = mydata[,order(mydata[1,])]
mydata.raw = mydata.raw[,order.dendrogram(dendro)]
my.lib.counts = lib.counts[order.dendrogram(dendro)]
mydata = mydata[,order.dendrogram(dendro)]

#layout(matrix(c(1,2,3,4),1,4,byrow=T),widths=c(3,2,5,5))
layout(matrix(c(1,2,3,4,4,4),2,3,byrow=T),widths=c(1,2,2),heights=c(1,1))

par(omd=c(0.01,0.99,0,0.95),mar=c(3,0.5,2,1),mgp=c(1.5,0.5,0))
#legend("center",inset=c(0,0),cex=1,fill=rainbow(nrow(mydata)),bty="n",legend=rownames(mydata))
plot(dendro,horiz=T,yaxt="n",leaflab="none")
par(mar=c(3,3,2,0))
b=barplot(mydata,las=2,horiz=T,col=rainbow(nrow(mydata)),main="Promoters",xlab="proportion",space=0)

ypos <- apply(mydata, 2, cumsum)
ypos <- ypos - mydata/2
ypos <- t(ypos)

text(ypos,b,t(mydata.raw),cex=ifelse(round(t(mydata)*100)>5,1,0.001),
	font=ifelse(t(apply(round(t(mydata)*100),1,function(x) x==max(x))),2,1),
	col=ifelse(t(apply(round(t(mydata)*100),1,function(x) x==max(x))),"white","black"))

par(mar=c(3,3,2,0))
if(!GENE %in% coverage$gene) barplot(colSums(mydata.raw)/my.lib.counts*1e6,las=2,horiz=T,names.arg="",main="Gene",xlab="tpm",space=0)
if(GENE %in% coverage$gene) {
coverage.temp = as.numeric(coverage[coverage$gene==GENE,-match("gene",colnames(coverage))])
barplot(coverage.temp[order.dendrogram(dendro)]/my.lib.counts*1e6,las=2,horiz=T,names.arg="",main="Gene",xlab="tpm",space=0)
}
title(paste(GENE),outer=T)


plot.new()
vps <- baseViewports()
vps$figure$clip = T
pushViewport(vps$inner)
pushViewport(vps$figure)
#grid.rect(gp=gpar(lwd=3, col="green"))
pushViewport(vps$plot)
#grid.rect(gp=gpar(lwd=3, col="blue"))
prom.data = osc2info(rownames(x))
RANGE = max(prom.data$end)-min(prom.data$start)
title = makeTitle(text = prom.data$chr[1],color = "Black")
genomeAxis = makeGenomeAxis(add53 = ifelse(prom.data$strand[1]=="+",T,F), add35=ifelse(prom.data$strand[1]=="-",T,F),dp=DisplayPars(cex=0.5))
gene = makeGene(id = as.character(entrez2hgnc[match(as.character(GENE),entrez2hgnc$gene),"entrez"]), type="entrezgene", biomart = mart)
transcript = makeTranscript(id = as.character(entrez2hgnc[match(as.character(GENE),entrez2hgnc$gene),"entrez"]), type="entrezgene", biomart = mart)

proms = makePromoterRegion(start=prom.data$start,end=prom.data$end,chromosome=as.numeric(strsplit(prom.data$chr,"chr")[[1]][2]),dp=DisplayPars(color=rainbow(nrow(mydata)),lty="blank"))
hr = list(); length(hr) = nrow(x)
for(i in 1:length(hr)) hr[[i]] = makeMyRectangleOverlay(heights=(rowSums(t(t(x)/lib.counts))/sum(t(t(x)/lib.counts)))[i],start=prom.data$start[i]-round(RANGE/100),end=prom.data$end[i]+round(RANGE/100),region=c(5,5),dp=DisplayPars(fill=rainbow(nrow(mydata))[i],lty="blank",alpha=0.3))
#plots heights of promoters after adjusting for library size
mygdplot(c(list(title,genomeAxis,gene=gene,transcripts=transcript),prom=proms),overlays=hr,minBase=min(prom.data$start)-round(RANGE/10),maxBase=max(prom.data$end)+round(RANGE/10),labelRot=0)

################
#all.combs.samples = unlist(apply(combn(ncol(mydata),2),2,list),recursive=F)
#all.combs.proms = unlist(apply(combn(nrow(mydata),2),2,list),recursive=F)
#all2by2  = mapply(function(x,y) mydata.raw[x,y],rep(all.combs.proms,length(all.combs.samples)),all.combs.samples[rep(1:length(all.combs.samples),rep(length(all.combs.proms),length(all.combs.samples)))],SIMPLIFY=F)
#temp = do.call(rbind,all2by2) + 0.5

#odd.numbers = seq(1,nrow(temp)-1,2)
#even.numbers = odd.numbers+1
#odds.ratios = as.numeric(temp[odd.numbers,1]*temp[even.numbers,2]/(temp[odd.numbers,2]*temp[even.numbers,1]))
#log.odds.ratios = log(odds.ratios)
#log.odds.se = as.numeric(sqrt(1/temp[odd.numbers,1]+1/temp[odd.numbers,2]+1/temp[even.numbers,1]+1/temp[even.numbers,2]))
#log.odds.z = log.odds.ratios/log.odds.se
#log.odds.pvalue = 2*pnorm(abs(log.odds.z),lower.tail=F)
#prom2col = rainbow(nrow(mydata));names(prom2col) = rownames(mydata)
#promcol1 = as.character(prom2col[unlist(lapply(all2by2,function(x) rownames(x)[1]))])
#promcol2 = as.character(prom2col[unlist(lapply(all2by2,function(x) rownames(x)[2]))])
#par(mar=c(3,3,2,1))
#plot(y=sqrt(-log(log.odds.pvalue,base=10)),x=log(odds.ratios,base=2),pch=21,col=ifelse(log.odds.pvalue<0.05 & abs(log.odds.ratios)>log(2),promcol2,rgb(0.75,0.75,0.75,0.3)),bg=ifelse(log.odds.pvalue<0.05 & abs(log.odds.ratios)>log(2),promcol1,"white"),lwd=2,cex=1.5,xlab=expression(paste(log[2],"(OR)")),ylab=expression( sqrt(-log[10]*" p-value") ),main="Switches")
#abline(h=sqrt(-log(0.05,base=10)),col="blue")
#abline(h=sqrt(-log(0.01,base=10)),col="red")
#abline(v=c(-1,1))
#text(y=sqrt(-log(log.odds.pvalue,base=10)),x=log(odds.ratios,base=2),labels=ifelse(log.odds.pvalue<0.05 & abs(log.odds.ratios)>log(2),unlist(lapply(all2by2,function(x) paste(colnames(x),collapse="-"))),""),pos=c(4,2),cex=0.5)
#mtext("p=0.05",side=4,line=0.5,at=sqrt(-log(0.05,base=10)),col="blue",cex=0.75)
#gexp.array = mapply(function(x,y) x[y],list(colSums(mydata.raw)/my.lib.counts*1e6),all.combs.samples[rep(1:length(all.combs.samples),rep(length(all.combs.proms),length(all.combs.samples)))])
#gexp =  gexp.array[2,] / gexp.array[1,]
#plot(y=log(gexp,base=2),x=log(odds.ratios,base=2),pch=ifelse(log.odds.pvalue<0.05,21,20),col=ifelse(log.odds.pvalue<0.05,promcol2,rgb(0.75,0.75,0.75,0.3)),bg=ifelse(log.odds.pvalue<0.05,promcol1,"white"),lwd=ifelse(log.odds.pvalue<0.05,2,1),cex=1.5,xlab=expression(paste("Promoter ",log[2],"(OR)")),ylab=expression(paste("Gene ",log[2]," (FC)")),main="Switches")
#text(y=log(gexp,base=2),x=log(odds.ratios,base=2),labels=ifelse(log.odds.pvalue<0.05,unlist(lapply(all2by2,function(x) paste(colnames(x),collapse="-"))),""),pos=3,cex=0.5)
#abline(v=0,h=0)
#options(locatorBell = FALSE)
#idx <- identify(x=log(odds.ratios,base=2),y=sqrt(-log(log.odds.pvalue,base=10)),labels=unlist(lapply(all2by2,function(x) paste(colnames(x),collapse="-"))))
#windows()
#plot.ca(ca(t(mydata.raw)[rowSums(t(mydata.raw))>0,,drop=F]),col=c("grey",rainbow(nrow(mydata),alpha=0.5)),main="Correspondence Analysis" ,mass = F, contrib = c("none","none"), map ="symmetric", arrows = c(F, F),labels=c(2,0))
#qgraph(cor(t(mydata)),color=rainbow(nrow(mydata)),edge.labels=ifelse(nrow(mydata)<10,T,F),borders=F,curveAll=T,curve=1,maximum=1,minimum=0,labels=F,edge.label.cex=3,mar=c(2,1,2,1))

return(rownames(mydata))
}
