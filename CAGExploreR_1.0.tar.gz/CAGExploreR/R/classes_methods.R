
setClass("PromoterRegion",contains="GeneModel")
setMethod("drawGD","PromoterRegion",function (gdObject, minBase, maxBase, vpPosition, ...) 
{
    .local <- function (gdObject, minBase, maxBase, vpPosition) 
    {
        model = cbind(GenomeGraphs:::getExonStart(gdObject),GenomeGraphs:::getExonEnd(gdObject))
        pushViewport(dataViewport(xData = c(minBase, maxBase), 
            yscale = c(0, 40), extension = 0, layout.pos.col = 1, 
            layout.pos.row = vpPosition))
        col = GenomeGraphs:::getColor(gdObject)
        for (i in seq(along = model[, 1])) {
            grid.rect(model[i, 1], 5, width = model[i, 1] - model[i, 
                2], height = 30, gp = gpar(col = "black", fill = col), 
                default.units = "native", just = c("right", "bottom"))
        }
        #for (j in seq(along = model[, 1])) {
        #    if (j < length(model[, 1])) {
        #        grid.lines(c(model[j, 2], model[j + 1, 1]), c(20, 
        #          20), default.units = "native", gp = gpar(col = col, 
        #          just = c("right", "bottom")))
        #    }
        #}
        popViewport()
    }
    .local(gdObject, minBase, maxBase, vpPosition, ...)
})
setMethod("initialize","Gene",
function (.Object, ...) 
{
    .Object <- callNextMethod()
	.Object@ens <- getBM.Object[getBM.Object$entrez==.Object@id,-8] 

    if (!is.null(.Object@ens)) {
        .Object@ens <- cbind(.Object@ens, biotype = rep("protein_coding", 
            length(.Object@ens[, 1])))
    }
    if (is.null(.Object@ens)) {
        setPar(.Object, "size", 0)
    }
    .Object
})

setMethod("initialize","Transcript",
function (.Object, ...) 
{
    .Object <- callNextMethod()
	.Object@ens <- getBM.Object[getBM.Object$entrez==.Object@id,-8] 

    if (!is.null(.Object@ens)) {
        .Object@ens <- cbind(.Object@ens, biotype = rep("protein_coding", 
            length(.Object@ens[, 1])))
    }
    if (is.null(.Object@ens)) {
        setPar(.Object@dp, "size", 0)
        .Object@numOfTranscripts <- 0
    }
    else {
        .Object@numOfTranscripts <- length(unique(.Object@ens[, 
            2]))
    }
    .Object
})


setClass("myRectangleOverlay",representation(heights = "numeric"),contains="RectangleOverlay")
setMethod(GenomeGraphs:::drawOverlay,"myRectangleOverlay",
function (obj, ...) 
{
    .local <- function (obj, minBase, maxBase, vplayout) 
    {
        switch(obj@coords, genomic = {
            ss <- (obj@start - minBase)/(maxBase - minBase)
            ee <- (obj@end - minBase)/(maxBase - minBase)
            if (is.null(obj@region)) {
                y0 <- 0
                height <- 1
            } else {
                region <- obj@region
                y0 <- 1 - sum(vplayout[1:region[2]])/sum(vplayout)
                height <- sum(vplayout[region[1]:region[2]])/sum(vplayout)
            }
        }, absolute = {
            ss <- obj@start
            ee <- obj@end
            y0 <- obj@region[1]
            height <- obj@region[2] - obj@region[1]
        }, stop("Unknown coordinate specification in HighlightRegion."))
        fill <- rgb(t(col2rgb(getPar(obj, "fill"))/255), alpha = getPar(obj, 
            "alpha"))
        color <- getPar(obj, "color")
        grid.rect(ss, y0, width = (ee - ss), height = obj@heights, 
            gp = gpar(fill = fill, col = color, lwd = GenomeGraphs:::getLwd(obj), 
                lty = GenomeGraphs:::getLty(obj)), just = c("left", "bottom"))
    }
    .local(obj, ...)
}
)
