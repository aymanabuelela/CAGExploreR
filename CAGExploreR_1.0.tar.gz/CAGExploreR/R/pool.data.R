pool.data <-
function(data)
{
library.counts = data$depth
data = data$counts
anot1cols = unlist(GREP(c("chr","strand","start","end"),colnames(data)))
datacols = grep("[[:punct:]0-9]{1,100}$",colnames(data))
anot2cols = setdiff(1:ncol(data),union(anot1cols,datacols))
temp.names = colnames(data)[datacols]
lib.names = unique(unlist(strsplit(temp.names,"[0-9]{1,100}$")))
n.lib = length(lib.names)
replicates = GREP(lib.names,colnames(data))
replicates.ord = GREP(lib.names,temp.names)

values = as.matrix(data[,unlist(replicates)]);class(values)="numeric"
#library.counts = colSums(values)
library.counts.list = lapply(replicates.ord,function(x) library.counts[x])
max.reps = max(unlist(lapply(library.counts.list,length)))
library.counts.matrix = matrix(NA,nrow=max.reps,ncol=length(library.counts.list))
colnames(library.counts.matrix) = lib.names
rownames(library.counts.matrix) = 1:max.reps
for(i in 1:length(lib.names))
{
	library.counts.matrix[1:length(library.counts.list[[i]]),i] = library.counts.list[[i]]
}

collapsed = as.data.frame(lapply(replicates,function(x) 
	{
		temp = as.matrix(data[,x])
		class(temp)="numeric"
		rowSums(temp)
	}))
#prom.counts = rowSums(collapsed)
#lib.counts = colSums(collapsed)
lib.counts = unlist(lapply(library.counts.list,sum))
data.sum = data.frame(data[,anot1cols],
	collapsed,
	gene=data[,anot2cols],check.names=F)
#77814    13 using F5
#12310 using mpromdb
data.sum = data.sum[rowSums(collapsed!=0)>0,]
#10592 using mpromdb
#41529 using F5 promoters with at least 1 conditions that have non-zero counts
full.coverage.genes = data.sum$gene[grep("@",data.sum$gene,fixed=T)]
full.coverage.data = data.sum[data.sum$gene %in% full.coverage.genes,]
singlepromgenes = names(table(data.sum$gene)[table(data.sum$gene)==1])
if(!is.null(singlepromgenes))data.sum = data.sum[!(data.sum$gene %in% singlepromgenes),]
#39683    17
rownames(data.sum) = info2osc(data.sum[,1:4])
rownames(full.coverage.data) = info2osc(full.coverage.data[,1:4])
full.coverage.data = full.coverage.data[,-match(c("chr","strand","start","end"),colnames(full.coverage.data))]
full.coverage.data$gene = unlist(lapply(strsplit(as.character(full.coverage.data$gene),"@"),function(x) x[1]))

#par(mfrow=c(2,1))
#barplot(sort(lib.counts/sum(lib.counts)),horiz=T,las=2);abline(v=1/n.lib)
#barplot(library.counts.matrix[,order(lib.counts)]/sum(library.counts.matrix),horiz=T,las=2);abline(v=1/n.lib)

i <- sapply(data.sum, is.factor)
data.sum[i] <- lapply(data.sum[i], as.character)
i <- sapply(data.sum, is.numeric)
data.sum[i] <- lapply(data.sum[i], as.integer)
by.gene = split(data.sum,as.character(data.sum$gene))
data.sum.data.cols = unlist(GREP(lib.names,colnames(data.sum)))
all.data = lapply(by.gene,function(x) as.matrix(x[,data.sum.data.cols]))
return(list(depth=lib.counts,coverage=full.coverage.data,data=all.data))
}
