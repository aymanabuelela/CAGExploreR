makePromoterRegion <-
function (start, end, chromosome, dp = NULL) 
{
    if (is.null(dp)) 
        dp <- getClass("PromoterRegion")@prototype@dp
    new("PromoterRegion", exonStart = start, exonEnd = end, dp = dp)
}
