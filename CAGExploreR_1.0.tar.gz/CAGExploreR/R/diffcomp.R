diffcomp <-
function(x,detailed=F,top="all",gene=NA,B=1000,seed=1,mc.adjust="fdr",text=TRUE) 
{
if(top=="all") top=length(x$data)
lib.counts = x$depth
n.lib = length(lib.counts)
all.data = x$data
if(!is.null(nrow(x$coverage))) coverage.data = x$coverage

#if(!detailed) mintags = unlist(lapply(all.data,function(x) min(colSums(x))))

#if(!detailed){
#suppressWarnings({
#pvalues = unlist(lapply(all.data,function(x) 
#{	
#	chisq.test(x)$p.value
#}))
#pvalues[which(is.na(pvalues))] = unlist(lapply(all.data[which(is.na(pvalues))],function(x) 
#{	
#	chisq.test(x+0.5)$p.value
#}))
#})

#chi2conditionpass = unlist(lapply(all.data,function(x) 
#{	
#	statistic = (matrix(rep(rowSums(x),ncol(x)),ncol=ncol(x))%*%diag(colSums(x)))/sum(x)
#	condition1 = sum(statistic >= 1) >= length(statistic)*0.5
#	return(condition1)
#}))
#qvalues = p.adjust(pvalues,mc.adjust)
#}

#pvalues[which(is.na(pvalues))]
#by.gene[which(is.na(pvalues))] investigate NA pvalues (small counts)

#sum(pvalues<0.05)
# 4148 genes

#sum(qvalues<0.05)
# 3556 genes

#entrezswitches = as.numeric(unlist(lapply(by.gene[which(qvalues<0.05)],function(x) x$entrez[1])))

#write.table(names(which(qvalues<0.05)),file="switching.genes.txt",quote=F,row.names=F,col.names=F,sep="\t")
#write.table(entrezswitches,file="switching.genes.txt",quote=F,row.names=F,col.names=F,sep="\t")

#switches.data = lapply(by.gene[which(qvalues<0.05)],function(x) as.matrix(x[,data.sum.data.cols]))

if(!detailed){
all.data.prop = lapply(all.data,function(x) x/sum(x))
all.data.row.prop = lapply(all.data,function(x) rowSums(x)/sum(x))
all.data.col.prop = lapply(all.data,function(x) colSums(x)/sum(x))

theilU.num = mapply(function(r,p,c) {
temp = (log(diag(1/r)%*%p%*%diag(1/c)))*p
temp[is.nan(temp)]=0
temp=-sum(temp)
return(temp)},all.data.row.prop,all.data.prop,all.data.col.prop)
theilU.den = unlist(lapply(all.data.row.prop,function(c) {
temp = entropy(c)
temp[is.nan(temp)]=0
return(sum(temp))
}))
theilU = theilU.num/theilU.den
theilU[is.nan(theilU)] = 0
theilU[theilU<0] = 0

#phi.inv = lapply(all.data,function(x){
#	x.bar.sq = mean(x)^2
#	sd.sq = sd(x)^2
#	phi.inverse = x.bar.sq/(sd.sq - x.bar.sq)	
#	if(phi.inverse<0) phi.inverse = 1e50
#	return(phi.inverse)
#})
u.pvalues = mapply(function(x,u) {
	gen.U(C=ncol(x),P=nrow(x),B=B,mu=rowMeans(x),cutoff=u,seed=seed)
},all.data,theilU)

u.qvalues = p.adjust(u.pvalues,mc.adjust)

geneHetero = unlist(base::mapply(function(x,y,z) 
{	if(!y) gene.prop = colSums(x)/lib.counts
	if(y) gene.prop = as.numeric(coverage.data[match(z,coverage.data$gene),-match("gene",colnames(coverage.data))]/lib.counts)
	temp=gene.prop/sum(gene.prop)
	return(1 - sum(entropy(temp))/log(1/n.lib))
},all.data,as.list(names(all.data)%in%coverage.data$gene),names(all.data),SIMPLIFY=F))#0: gene expressed equally across all samples, 1: DEG

#promHetero = unlist(lapply(all.data,function(x) 
#{	
#	prom.prop = t(t(x)/colSums(as.matrix(x)))
#	temp=prom.prop/rowSums(prom.prop)
#	values = apply(temp,1,function(x) sum(entropy(x))/log(1/n.lib))
#	return(1-min(values))
#} ))#0: most variable promoter expressed equally across all samples, 1: DEP

Coverage = unlist(base::mapply(function(x,y,z) 
{	if(!y) return(NA)
	gene.total = as.numeric(coverage.data[match(z,coverage.data$gene),-match("gene",colnames(coverage.data))])
	return(mean(colSums(x)/gene.total,na.rm=T))
},all.data,as.list(names(all.data)%in%coverage.data$gene),names(all.data),SIMPLIFY=F))#0: gene expressed equally across all samples, 1: DEG

qvalue.text = mc.adjust
if(mc.adjust=="none") qvalue.text = "pvalue"

Dominating = unlist(lapply(all.data,function(x) dominating(x)))

significance.pars = data.frame(entropy.Reduction=theilU,U.FDR=u.qvalues,geneHetero=geneHetero,coverage=Coverage,dominant.promoter.switch=Dominating)
colnames(significance.pars)[2] = qvalue.text
#significance.pars = data.frame(Entropy.Reduction=theilU,ChiSq.FDR=qvalues,Valid=chi2conditionpass,U.FDR=u.qvalues,MinTags=mintags,GeneHetero=geneHetero,PromHetero=promHetero,Coverage=Coverage)
#sig.results = significance.pars[significance.pars[,2]<=q,]
significance.pars = significance.pars[order(-significance.pars[,1],significance.pars[,2]),]
return(significance.pars)
} #end if(!detailed)

if(detailed) {

all.data.prop = lapply(all.data,function(x) x/sum(x))
all.data.row.prop = lapply(all.data,function(x) rowSums(x)/sum(x))
all.data.col.prop = lapply(all.data,function(x) colSums(x)/sum(x))

theilU.num = mapply(function(r,p,c) {
temp = (log(diag(1/r)%*%p%*%diag(1/c)))*p
temp[is.nan(temp)]=0
temp=-sum(temp)
return(temp)},all.data.row.prop,all.data.prop,all.data.col.prop)
theilU.den = unlist(lapply(all.data.row.prop,function(c) {
temp = entropy(c)
temp[is.nan(temp)]=0
return(sum(temp))
}))
theilU = theilU.num/theilU.den
theilU[is.nan(theilU)] = 0
theilU = theilU[order(-theilU)]

if(is.na(gene[1])) {results.list = lapply(as.list(names(theilU)[1:top]),get.table,data=x,text=text)}
if(!is.na(gene[1])) {results.list = lapply(as.list(gene),get.table,data=x,text=text)}

#results.list = do.call(rbind,results.list)
results.list = as.data.frame(rbindlist(results.list))
results.list$local.qvalue = p.adjust(results.list$pvalue,mc.adjust)
qvalue.text = mc.adjust
if(mc.adjust=="none") qvalue.text = "pvalue"
colnames(results.list)[ncol(results.list)] = qvalue.text

rownames(results.list) = NULL
return(results.list)
}

}
