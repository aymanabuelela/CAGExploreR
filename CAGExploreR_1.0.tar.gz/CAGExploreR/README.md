CAGExploreR
===========
Please see the Vignette for installation instructions and an example workflow.



[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/edimont/cagexplorer/trend.png)](https://bitdeli.com/free "Bitdeli Badge")
